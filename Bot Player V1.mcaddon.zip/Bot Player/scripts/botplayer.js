import * as GameTest from "mojang-gametest";
import { world,BlockLocation } from "mojang-minecraft";
import { ActionFormData } from "mojang-minecraft-ui";

world.events.beforeChat.subscribe((yasser) => { 
	if (yasser.message.startsWith("-bot")) {
		yasser.cancel = true;
		yasser.sender.runCommand("give @p yasser:botplayermenu");
		}});

world.events.beforeItemUse.subscribe((yasser) => {
    const player = yasser.source
    if(yasser.item.id == "yasser:botplayermenu") {
    	BotPlayerMenu(player);
    }});
 
    function BotPlayerMenu(player) {
    const form = new ActionFormData()
      .title("§1§l[BOT] §l§aPlayer §4Menu")
      .body("§a§o§lBY YASSER DZ")      
      .button("§l§0Summon Bot Player","textures/ui/icon_steve")
      .button("§l§0Bot Player Settings","textures/ui/gear")      
      .button("§l§0Remove Bot Player","textures/ui/realms_red_x")      
form.show(player).then(result => {   
  if (result.selection === 0) {
        player.runCommand(`gametest run yasser:botplayer`)
        }
  if (result.selection === 1) {
        BotPlayerSettings(player);
        }
   if (result.selection === 2) {       
        player.runCommand(`gametest clearall`)      
      }})}

   function BotPlayerSettings(player) {
    const form = new ActionFormData()
      .title("§1§l[BOT] §l§aPlayer §4Settings")
      .body("§a§o§lBY YASSER DZ")      
      .button("§l§0GameMode","textures/ui/heart_background")
      .button("§l§0Effects","textures/items/potion_bottle_jump")      
      .button("§l§0Teleport","textures/ui/gear")            
      .button("§l§0Close","textures/ui/arrow_left")            
form.show(player).then(result => {   
  if (result.selection === 0) {
       BotPlayerGamemode(player);
        }
  if (result.selection === 1) {       
BotPlayerEffects(player);
}
  if (result.selection === 2) {       
BotPlayerTeleport(player);
}
  if (result.selection === 3) {       
BotPlayerMenu(player);
      }})}

   function BotPlayerGamemode(player) {
    const form = new ActionFormData()
      .title("§1§l[BOT] §l§aPlayer §4Gamemode")
      .body("§a§o§lBY YASSER DZ")      
      .button("§l§0Default","textures/ui/icon_map")
      .button("§l§0Adventure","textures/ui/icon_agent")      
      .button("§l§0Survival","textures/ui/heart_new")
      .button("§l§0Creative","textures/ui/op")      
      .button("§l§0Spectator","textures/items/ender_pearl")
      .button("§l§0Close","textures/ui/arrow_left")            
form.show(player).then(result => {   
  if (result.selection === 0) {
                player.runCommand(`Gamemode d "§l§a[§1BOT§a] §lPlayer"`)        
            }
  if (result.selection === 1) {
                player.runCommand(`Gamemode a "§l§a[§1BOT§a] §lPlayer"`)        
          }               
  if (result.selection === 2) {
                player.runCommand(`Gamemode s "§l§a[§1BOT§a] §lPlayer"`)
            }
  if (result.selection === 3) {
                player.runCommand(`Gamemode c "§l§a[§1BOT§a] §lPlayer"`)
            }
  if (result.selection === 4) {
                player.runCommand(`Gamemode spectator "§l§a[§1BOT§a] §lPlayer"`)   
            }
  if (result.selection === 5) {
                BotPlayerSettings(player);
      }})}

   function BotPlayerEffects(player) {
    const form = new ActionFormData()
      .title("§1§l[BOT] §l§aPlayer §4Effects")
      .body("§a§o§lBY YASSER DZ")      
      .button("§l§0Health Boost","textures/ui/health_boost_effect")
      .button("§l§0Instant Health","textures/gui/newgui/mob_effects/regeneration_effect")      
      .button("§l§0Invisibility","textures/gui/newgui/mob_effects/invisibility_effect")      
      .button("§l§0Clear","textures/ui/realms_red_x")            
      .button("§l§0Close","textures/ui/arrow_left")                  
form.show(player).then(result => {   
  if (result.selection === 0) {
                player.runCommand(`effect "§l§a[§1BOT§a] §lPlayer" health_boost 999999999 255`)        
            }
  if (result.selection === 1) {
                player.runCommand(`effect "§l§a[§1BOT§a] §lPlayer" instant_health 999999999 255`)        
          }               
  if (result.selection === 2) {
                player.runCommand(`effect "§l§a[§1BOT§a] §lPlayer" invisibility 999999999 255`)
            }
  if (result.selection === 3) {
                player.runCommand(`effect "§l§a[§1BOT§a] §lPlayer" clear`)
            }
  if (result.selection === 4) {
                BotPlayerSettings(player);
      }})}

   function BotPlayerTeleport(player) {
    const form = new ActionFormData()
      .title("§1§l[BOT] §l§aPlayer §4Teleport")
      .body("§a§o§lBY YASSER DZ")      
      .button("§l§0Go a Him","textures/ui/book_arrowright_default")
      .button("§l§0To Me","textures/ui/book_arrowleft_default")      
      .button("§l§0Close","textures/ui/arrow_left")            
form.show(player).then(result => {   
  if (result.selection === 0) {
                player.runCommand(`tp @p "§l§a[§1BOT§a] §lPlayer"`)        
            }
  if (result.selection === 1) {
                player.runCommand(`tp "§l§a[§1BOT§a] §lPlayer" @p`)     
}
  if (result.selection === 2) {
                BotPlayerSettings(player);
      }})}               
    
GameTest.registerAsync("Yasser", "botplayer", async (test) => {
  const thePlayerName = "§l§a[§1BOT§a] §lPlayer";

  let expectedPlayerJoined = false;
  const playerJoinCallback = world.events.playerJoin.subscribe((e) => {
    if (e.player.name == thePlayerName) {
      expectedPlayerJoined = true;
    }
  });

  let simPlayer = test.spawnSimulatedPlayer(new BlockLocation(0, 4, 0), thePlayerName);
  simPlayer.runCommand(`gamerule domobspawning true`)        
await test.idle(999999998);  
  if (!expectedPlayerJoined) {
    test.fail("§l§a[§1BOT§a] §lPlayer");
  }

  world.events.playerJoin.unsubscribe(playerJoinCallback); 
  
test.succeed(); 
})
  .maxTicks(999999999)
  .structureName("1:yasser")
  .tag(GameTest.Tags.suiteDefault);
      